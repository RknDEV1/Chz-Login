#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build/chzlogin-ios"
DEVICE_DIR="$BUILD_DIR/iphoneos"
PUBLIC_DIR="$BUILD_DIR/PublicHeaders"
OUTPUT_DIR="$ROOT_DIR/build/ChzLogin.xcframework"
SDK_NAME="${SDK_NAME:-iphoneos}"
MIN_IOS="${IPHONEOS_DEPLOYMENT_TARGET:-16.0}"
SDK_PATH="$(xcrun --sdk "$SDK_NAME" --show-sdk-path)"
CLANG="$(xcrun --sdk "$SDK_NAME" -f clang)"
SDK_VERSION="$(xcrun --sdk "$SDK_NAME" --show-sdk-version)"

if [[ "$MIN_IOS" != "16.0" ]]; then
    echo "This build must keep IPHONEOS_DEPLOYMENT_TARGET=16.0; received $MIN_IOS" >&2
    exit 3
fi

SECRETS_HEADER=""
for candidate in "$ROOT_DIR/ChzAuth/Sources/CHZSecrets.h" "$ROOT_DIR/Config/CHZSecrets.h"; do
    if [[ -f "$candidate" ]]; then
        SECRETS_HEADER="$candidate"
        break
    fi
done

if [[ -z "$SECRETS_HEADER" ]]; then
    echo "Missing CHZSecrets.h. Create it locally from CHZSecrets.example.h; do not commit secrets." >&2
    exit 2
fi

rm -rf "$BUILD_DIR" "$OUTPUT_DIR"
mkdir -p "$DEVICE_DIR/Objects" "$PUBLIC_DIR"

COMMON_FLAGS=(
    -arch arm64
    -isysroot "$SDK_PATH"
    -miphoneos-version-min="$MIN_IOS"
    -DCHZ_LOGIN_MIN_IOS=16
    -fobjc-arc
    -fmodules
    -I"$ROOT_DIR/ChzAuth/Sources"
    -I"$ROOT_DIR/ChzAuth/Vendor/API"
    -I"$(dirname "$SECRETS_HEADER")"
)

SOURCES=(
    "$ROOT_DIR/ChzAuth/Sources/CHZAuthManager.m"
    "$ROOT_DIR/ChzAuth/Sources/CHZKeychain.m"
    "$ROOT_DIR/ChzAuth/Sources/CHZLoginViewController.m"
)

OBJECTS=()
for source in "${SOURCES[@]}"; do
    name="$(basename "${source%.m}")"
    object="$DEVICE_DIR/Objects/$name.o"
    "$CLANG" "${COMMON_FLAGS[@]}" -c "$source" -o "$object"
    OBJECTS+=("$object")
done

"$CLANG" \
    -dynamiclib \
    -arch arm64 \
    -isysroot "$SDK_PATH" \
    -miphoneos-version-min="$MIN_IOS" \
    -install_name "@rpath/ChzLogin.framework/ChzLogin" \
    -fobjc-arc \
    -Wl,-dead_strip \
    "${OBJECTS[@]}" \
    -Wl,-force_load,"$ROOT_DIR/ChzAuth/Vendor/API/libAPIClient.a" \
    -framework Foundation \
    -framework UIKit \
    -framework Security \
    -framework CFNetwork \
    -framework CoreFoundation \
    -framework CoreGraphics \
    -framework QuartzCore \
    -framework SystemConfiguration \
    -lc++ \
    -o "$DEVICE_DIR/ChzLogin"

cp "$ROOT_DIR/ChzAuth/Sources/CHZAuthManager.h" "$PUBLIC_DIR/"
cp "$ROOT_DIR/ChzAuth/Sources/CHZKeychain.h" "$PUBLIC_DIR/"
cp "$ROOT_DIR/ChzAuth/Sources/CHZLoginViewController.h" "$PUBLIC_DIR/"

cat > "$PUBLIC_DIR/module.modulemap" <<'MODULEMAP'
framework module ChzLogin {
    umbrella header "CHZAuthManager.h"
    export *
    module * { export * }
}
MODULEMAP

mkdir -p "$OUTPUT_DIR/ios-arm64/ChzLogin.framework/Headers"
cp "$DEVICE_DIR/ChzLogin" "$OUTPUT_DIR/ios-arm64/ChzLogin.framework/ChzLogin"
cp "$PUBLIC_DIR"/*.h "$OUTPUT_DIR/ios-arm64/ChzLogin.framework/Headers/"
cp "$PUBLIC_DIR/module.modulemap" "$OUTPUT_DIR/ios-arm64/ChzLogin.framework/"
cat > "$OUTPUT_DIR/ios-arm64/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundlePackageType</key><string>XFWK</string>
<key>CFBundleIdentifier</key><string>com.chzpriv.ChzLogin</string>
<key>CFBundleName</key><string>ChzLogin</string>
<key>CFBundleVersion</key><string>1</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>MinimumOSVersion</key><string>16.0</string>
<key>CFBundleSupportedPlatforms</key><array><string>iPhoneOS</string></array>
<key>AvailableArchitectures</key><array><string>arm64</string></array>
</dict></plist>
PLIST

cat > "$OUTPUT_DIR/BuildInfo.txt" <<INFO
SDK_NAME=$SDK_NAME
SDK_VERSION=$SDK_VERSION
IPHONEOS_DEPLOYMENT_TARGET=$MIN_IOS
ARCH=arm64
INFO

echo "Built device framework at: $OUTPUT_DIR/ios-arm64/ChzLogin.framework"
echo "SDK: $SDK_NAME $SDK_VERSION | minimum iOS: $MIN_IOS | architecture: arm64"
echo "For distribution, sign the framework with the same identity as the host app and embed it with Embed & Sign."
